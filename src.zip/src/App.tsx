import "./App.css";
import RouterConfig from "./libs/router";

function App() {
  return (
   <RouterConfig/>
  );
}

export default App;
